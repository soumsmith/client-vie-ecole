import React, { useState, useCallback, useEffect } from "react";
import { 
    Button, 
    Modal, 
    Row, 
    Col, 
    Message, 
    Loader, 
    Badge,
    SelectPicker,
    Uploader,
    IconButton,
    Table,
    Panel,
    Form,
    Input,
    InputNumber,
    DatePicker,
    Notification
} from 'rsuite';
import { 
    FiUpload, 
    FiDownload, 
    FiFile,
    FiCheck,
    FiX,
    FiRefreshCw,
    FiEye,
    FiTrash2,
    FiEdit,
    FiPlus,
    FiBook,
    FiCalendar,
    FiClock,
    FiHash
} from 'react-icons/fi';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';

const { Column, HeaderCell, Cell } = Table;

// ===========================
// COMPOSANT PRINCIPAL
// ===========================
const ProgressionPedagogique = () => {
    const [showLoadModal, setShowLoadModal] = useState(false);
    const [showDetailsModal, setShowDetailsModal] = useState(false);
    const [showFormModal, setShowFormModal] = useState(false);
    const [progressions, setProgressions] = useState([]);
    const [selectedProgression, setSelectedProgression] = useState(null);
    const [detailsData, setDetailsData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [formMode, setFormMode] = useState('add'); // 'add' ou 'edit'
    const [selectedDetail, setSelectedDetail] = useState(null);

    // Données pour les combobox
    const [anneesData, setAnneesData] = useState([]);
    const [selectedAnnee, setSelectedAnnee] = useState(null);

    // Charger les années scolaires
    useEffect(() => {
        const fetchAnnees = async () => {
            try {
                const response = await fetch('https://api-pro.pouls-scolaire.net/api/annee/list-to-central');
                const data = await response.json();
                const formattedData = data.map(annee => ({
                    value: annee.id,
                    label: annee.customLibelle,
                    niveauEnseignement: annee.niveauEnseignement
                }));
                setAnneesData(formattedData);
            } catch (error) {
                console.error('Erreur chargement années:', error);
            }
        };
        fetchAnnees();
    }, []);

    // Charger progressions par année
    const loadProgressionsByAnnee = async (anneeId) => {
        try {
            setLoading(true);
            const response = await fetch(`https://api-pro.pouls-scolaire.net/api/progression/get-by-annee/${anneeId}`);
            const data = await response.json();
            setProgressions(data);
        } catch (error) {
            console.error('Erreur chargement progressions:', error);
            Notification.error({
                title: 'Erreur',
                description: 'Erreur lors du chargement des progressions'
            });
        } finally {
            setLoading(false);
        }
    };

    // Charger détails d'une progression
    const loadProgressionDetails = async (progressionId) => {
        try {
            setLoading(true);
            const response = await fetch(`https://api-pro.pouls-scolaire.net/api/detail-progression/get-by-progression/${progressionId}`);
            const data = await response.json();
            setDetailsData(data);
        } catch (error) {
            console.error('Erreur chargement détails:', error);
            Notification.error({
                title: 'Erreur',
                description: 'Erreur lors du chargement des détails'
            });
        } finally {
            setLoading(false);
        }
    };

    const handleViewDetails = async (progression) => {
        setSelectedProgression(progression);
        await loadProgressionDetails(progression.id);
        setShowDetailsModal(true);
    };

    const handleAddDetail = () => {
        setFormMode('add');
        setSelectedDetail(null);
        setShowFormModal(true);
    };

    const handleEditDetail = (detail) => {
        setFormMode('edit');
        setSelectedDetail(detail);
        setShowFormModal(true);
    };

    // ===========================
    // MODAL DE CHARGEMENT
    // ===========================
    const LoadProgressionModal = () => {
        const [selectedNiveau, setSelectedNiveau] = useState(null);
        const [selectedAnneeLocal, setSelectedAnneeLocal] = useState(null);
        const [selectedBranche, setBranche] = useState(null);
        const [selectedMatiere, setMatiere] = useState(null);
        const [fileData, setFileData] = useState([]);
        const [fileInfo, setFileInfo] = useState(null);

        const niveauxData = [
            { value: 1, label: "Enseignement Primaire" },
            { value: 2, label: "Enseignement Secondaire Générale" },
            { value: 3, label: "Enseignement Technique" }
        ];

        const branchesData = [
            { value: 1, label: "6EME" },
            { value: 2, label: "5EME" },
            { value: 3, label: "4EME" },
            { value: 4, label: "3EME" }
        ];

        const matieresData = [
            { value: 1, label: "FRANÇAIS" },
            { value: 2, label: "MATHÉMATIQUES" },
            { value: 3, label: "SCIENCES" },
            { value: 4, label: "HISTOIRE" },
            { value: 5, label: "ANGLAIS" }
        ];

        const parseFile = (file) => {
            const fileExtension = file.name.toLowerCase().split('.').pop();
            
            if (fileExtension === 'csv') {
                Papa.parse(file, {
                    header: true,
                    skipEmptyLines: true,
                    complete: (results) => {
                        setFileData(results.data);
                        setFileInfo({ name: file.name, size: file.size });
                    }
                });
            } else if (['xls', 'xlsx'].includes(fileExtension)) {
                const reader = new FileReader();
                reader.onload = (e) => {
                    const data = new Uint8Array(e.target.result);
                    const workbook = XLSX.read(data, { type: 'array' });
                    const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
                    const jsonData = XLSX.utils.sheet_to_json(firstSheet);
                    setFileData(jsonData);
                    setFileInfo({ name: file.name, size: file.size });
                };
                reader.readAsArrayBuffer(file);
            }
        };

        const handleFileUpload = (fileList) => {
            if (fileList.length > 0) {
                parseFile(fileList[0].blobFile);
            }
        };

        const handleSave = () => {
            // Ici vous pouvez implémenter la sauvegarde
            Notification.success({
                title: 'Succès',
                description: 'Progression chargée avec succès'
            });
            setShowLoadModal(false);
        };

        return (
            <Modal open={showLoadModal} onClose={() => setShowLoadModal(false)} size="lg">
                <Modal.Header>
                    <Modal.Title>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                            <div style={{
                                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                                borderRadius: '10px',
                                padding: '8px',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center'
                            }}>
                                <FiUpload size={18} color="white" />
                            </div>
                            Formulaire de chargement des progressions
                        </div>
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Row gutter={20}>
                        <Col xs={12}>
                            <div style={{ marginBottom: '15px' }}>
                                <label style={{ display: 'block', marginBottom: '5px', fontWeight: '500' }}>
                                    Niveau d'enseignement
                                </label>
                                <SelectPicker
                                    data={niveauxData}
                                    value={selectedNiveau}
                                    onChange={setSelectedNiveau}
                                    placeholder="Sélectionner le niveau"
                                    style={{ width: '100%' }}
                                    cleanable={false}
                                />
                            </div>
                        </Col>
                        <Col xs={12}>
                            <div style={{ marginBottom: '15px' }}>
                                <label style={{ display: 'block', marginBottom: '5px', fontWeight: '500' }}>
                                    Année scolaire
                                </label>
                                <SelectPicker
                                    data={anneesData}
                                    value={selectedAnneeLocal}
                                    onChange={setSelectedAnneeLocal}
                                    placeholder="Sélectionner l'année"
                                    style={{ width: '100%' }}
                                    cleanable={false}
                                />
                            </div>
                        </Col>
                    </Row>

                    <Row gutter={20} style={{ marginTop: 15 }}>
                        <Col xs={12}>
                            <div style={{ marginBottom: '15px' }}>
                                <label style={{ display: 'block', marginBottom: '5px', fontWeight: '500' }}>
                                    Branche
                                </label>
                                <SelectPicker
                                    data={branchesData}
                                    value={selectedBranche}
                                    onChange={setBranche}
                                    placeholder="Sélectionner la branche"
                                    style={{ width: '100%' }}
                                    cleanable={false}
                                />
                            </div>
                        </Col>
                        <Col xs={12}>
                            <div style={{ marginBottom: '15px' }}>
                                <label style={{ display: 'block', marginBottom: '5px', fontWeight: '500' }}>
                                    Matière
                                </label>
                                <SelectPicker
                                    data={matieresData}
                                    value={selectedMatiere}
                                    onChange={setMatiere}
                                    placeholder="Sélectionner la matière"
                                    style={{ width: '100%' }}
                                    cleanable={false}
                                />
                            </div>
                        </Col>
                    </Row>

                    <div style={{ marginTop: 20, marginBottom: 20 }}>
                        <label style={{ display: 'block', marginBottom: '8px', fontWeight: '500' }}>
                            Sélectionner le fichier
                        </label>
                        <div style={{
                            border: '2px dashed #d1d5db',
                            borderRadius: '12px',
                            padding: '30px 20px',
                            textAlign: 'center',
                            backgroundColor: '#f8fafc'
                        }}>
                            <Uploader
                                fileListVisible={false}
                                onChange={handleFileUpload}
                                accept=".csv,.xls,.xlsx"
                                draggable
                                autoUpload={false}
                            >
                                <div>
                                    <FiFile size={48} color="#667eea" />
                                    <p style={{ margin: '10px 0', fontSize: '16px', fontWeight: '500' }}>
                                        Cliquez ou glissez-déposez votre fichier ici
                                    </p>
                                    <p style={{ margin: 0, color: '#64748b', fontSize: '14px' }}>
                                        Formats acceptés: CSV, Excel (.xls, .xlsx)
                                    </p>
                                </div>
                            </Uploader>
                        </div>
                        
                        {fileInfo && (
                            <div style={{
                                marginTop: 15,
                                padding: '10px 15px',
                                backgroundColor: '#ecfdf5',
                                border: '1px solid #10b981',
                                borderRadius: '8px',
                                display: 'flex',
                                alignItems: 'center',
                                gap: 10
                            }}>
                                <FiFile color="#10b981" />
                                <span style={{ fontWeight: '500' }}>{fileInfo.name}</span>
                                <span style={{ color: '#64748b', fontSize: '12px' }}>
                                    ({(fileInfo.size / 1024).toFixed(1)} KB)
                                </span>
                            </div>
                        )}
                    </div>

                    {fileData.length > 0 && (
                        <div style={{ marginTop: 20 }}>
                            <h6>Prévisualisation des données ({fileData.length} lignes)</h6>
                            <div style={{ maxHeight: 300, overflow: 'auto' }}>
                                <Table height={300} data={fileData.slice(0, 10)}>
                                    {Object.keys(fileData[0] || {}).map(key => (
                                        <Column key={key} flexGrow={1}>
                                            <HeaderCell>{key}</HeaderCell>
                                            <Cell dataKey={key} />
                                        </Column>
                                    ))}
                                </Table>
                            </div>
                        </div>
                    )}
                </Modal.Body>
                <Modal.Footer>
                    <Button onClick={() => setShowLoadModal(false)} appearance="subtle">
                        Annuler
                    </Button>
                    <Button onClick={handleSave} appearance="primary">
                        Enregistrer
                    </Button>
                </Modal.Footer>
            </Modal>
        );
    };

    // ===========================
    // MODAL DES DÉTAILS
    // ===========================
    const DetailsModal = () => {
        const formatDate = (dateStr) => {
            if (!dateStr) return 'Non définie';
            return dateStr;
        };

        return (
            <Modal open={showDetailsModal} onClose={() => setShowDetailsModal(false)} size="lg">
                <Modal.Header>
                    <Modal.Title>Détails de la Progression</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {selectedProgression && (
                        <div style={{ marginBottom: 20 }}>
                            <Panel bordered>
                                <div style={{ padding: '15px' }}>
                                    <Row gutter={20}>
                                        <Col xs={6}>
                                            <div style={{ marginBottom: 10 }}>
                                                <span style={{ color: '#3498db', fontSize: '12px', textTransform: 'uppercase', fontWeight: '600' }}>
                                                    Année :
                                                </span>
                                                <div style={{ fontSize: '14px', fontWeight: '500', marginTop: 3 }}>
                                                    {selectedProgression.annee?.libelle}
                                                </div>
                                            </div>
                                        </Col>
                                        <Col xs={6}>
                                            <div style={{ marginBottom: 10 }}>
                                                <span style={{ color: '#3498db', fontSize: '12px', textTransform: 'uppercase', fontWeight: '600' }}>
                                                    Niveau d'enseignement :
                                                </span>
                                                <div style={{ fontSize: '14px', fontWeight: '500', marginTop: 3 }}>
                                                    {selectedProgression.niveau?.libelle}
                                                </div>
                                            </div>
                                        </Col>
                                        <Col xs={6}>
                                            <div style={{ marginBottom: 10 }}>
                                                <span style={{ color: '#3498db', fontSize: '12px', textTransform: 'uppercase', fontWeight: '600' }}>
                                                    Branche :
                                                </span>
                                                <div style={{ fontSize: '14px', fontWeight: '500', marginTop: 3 }}>
                                                    {selectedProgression.branche?.libelle}
                                                </div>
                                            </div>
                                        </Col>
                                        <Col xs={6}>
                                            <div style={{ marginBottom: 10 }}>
                                                <span style={{ color: '#3498db', fontSize: '12px', textTransform: 'uppercase', fontWeight: '600' }}>
                                                    Matière :
                                                </span>
                                                <div style={{ fontSize: '14px', fontWeight: '500', marginTop: 3 }}>
                                                    {selectedProgression.matiere?.libelle}
                                                </div>
                                            </div>
                                        </Col>
                                    </Row>
                                </div>
                            </Panel>
                        </div>
                    )}

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 15 }}>
                        <h6>Détails de la progression</h6>
                        <Button 
                            appearance="primary" 
                            size="sm"
                            onClick={handleAddDetail}
                            startIcon={<FiPlus />}
                        >
                            Ajouter
                        </Button>
                    </div>

                    <Table 
                        height={400} 
                        data={detailsData}
                        loading={loading}
                    >
                        <Column width={80} fixed>
                            <HeaderCell>Période</HeaderCell>
                            <Cell>
                                {rowData => rowData.periode?.libelle || 'N/A'}
                            </Cell>
                        </Column>

                        <Column width={100}>
                            <HeaderCell>Date Début</HeaderCell>
                            <Cell>
                                {rowData => (
                                    <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                                        <FiCalendar size={12} color="#64748b" />
                                        <span style={{ fontSize: '12px' }}>
                                            {formatDate(rowData.dateDeb)}
                                        </span>
                                    </div>
                                )}
                            </Cell>
                        </Column>

                        <Column width={100}>
                            <HeaderCell>Date Fin</HeaderCell>
                            <Cell>
                                {rowData => (
                                    <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                                        <FiCalendar size={12} color="#64748b" />
                                        <span style={{ fontSize: '12px' }}>
                                            {formatDate(rowData.dateFin)}
                                        </span>
                                    </div>
                                )}
                            </Cell>
                        </Column>

                        <Column width={80}>
                            <HeaderCell>Numéro</HeaderCell>
                            <Cell>
                                {rowData => (
                                    <Badge 
                                        style={{ backgroundColor: '#667eea', color: 'white' }}
                                        content={rowData.numLecon}
                                    />
                                )}
                            </Cell>
                        </Column>

                        <Column flexGrow={2}>
                            <HeaderCell>Titre</HeaderCell>
                            <Cell>
                                {rowData => (
                                    <div>
                                        <div style={{ fontWeight: '500', fontSize: '13px' }}>
                                            {rowData.titre}
                                        </div>
                                    </div>
                                )}
                            </Cell>
                        </Column>

                        <Column width={80}>
                            <HeaderCell>Nbre. Heure</HeaderCell>
                            <Cell>
                                {rowData => (
                                    <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                                        <FiClock size={12} color="#64748b" />
                                        {rowData.heure}
                                    </div>
                                )}
                            </Cell>
                        </Column>

                        <Column width={80}>
                            <HeaderCell>Nbre. Séance</HeaderCell>
                            <Cell dataKey="nbreSeance" />
                        </Column>

                        <Column width={80}>
                            <HeaderCell>Ordre</HeaderCell>
                            <Cell>
                                {rowData => (
                                    <Badge content={rowData.ordre} style={{ backgroundColor: '#10b981' }} />
                                )}
                            </Cell>
                        </Column>

                        <Column width={120} fixed="right">
                            <HeaderCell>Actions</HeaderCell>
                            <Cell>
                                {rowData => (
                                    <div style={{ display: 'flex', gap: 5 }}>
                                        <IconButton
                                            icon={<FiEdit />}
                                            size="sm"
                                            onClick={() => handleEditDetail(rowData)}
                                            style={{ color: '#3498db' }}
                                        />
                                        <IconButton
                                            icon={<FiTrash2 />}
                                            size="sm"
                                            color="red"
                                            appearance="subtle"
                                        />
                                    </div>
                                )}
                            </Cell>
                        </Column>
                    </Table>
                </Modal.Body>
                <Modal.Footer>
                    <Button onClick={() => setShowDetailsModal(false)} appearance="subtle">
                        Fermer
                    </Button>
                </Modal.Footer>
            </Modal>
        );
    };

    // ===========================
    // MODAL DE FORMULAIRE
    // ===========================
    const FormModal = () => {
        const [formData, setFormData] = useState({
            periode: '',
            dateDeb: '',
            dateFin: '',
            numLecon: 1,
            titre: '',
            heure: 3,
            nbreSeance: 3,
            ordre: 1
        });

        useEffect(() => {
            if (formMode === 'edit' && selectedDetail) {
                setFormData({
                    periode: selectedDetail.periode?.id || '',
                    dateDeb: selectedDetail.dateDeb || '',
                    dateFin: selectedDetail.dateFin || '',
                    numLecon: selectedDetail.numLecon || 1,
                    titre: selectedDetail.titre || '',
                    heure: selectedDetail.heure || 3,
                    nbreSeance: selectedDetail.nbreSeance || 3,
                    ordre: selectedDetail.ordre || 1
                });
            }
        }, [formMode, selectedDetail]);

        const periodesData = [
            { value: 1, label: "Premier Trimestre" },
            { value: 2, label: "Deuxième Trimestre" },
            { value: 3, label: "Troisième Trimestre" }
        ];

        const handleSave = () => {
            Notification.success({
                title: 'Succès',
                description: `Détail ${formMode === 'add' ? 'ajouté' : 'modifié'} avec succès`
            });
            setShowFormModal(false);
        };

        return (
            <Modal open={showFormModal} onClose={() => setShowFormModal(false)} size="md">
                <Modal.Header>
                    <Modal.Title>
                        {formMode === 'add' ? 'Ajouter un détail' : 'Modifier un détail'}
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
                        <Row gutter={16}>
                            <Col xs={24}>
                                <div style={{ marginBottom: '15px' }}>
                                    <label style={{ display: 'block', marginBottom: '5px', fontWeight: '500' }}>
                                        Période *
                                    </label>
                                    <SelectPicker
                                        data={periodesData}
                                        value={formData.periode}
                                        onChange={value => setFormData(prev => ({...prev, periode: value}))}
                                        placeholder="Sélectionner une période"
                                        style={{ width: '100%' }}
                                        cleanable={false}
                                    />
                                </div>
                            </Col>
                        </Row>

                        <Row gutter={16}>
                            <Col xs={12}>
                            <div style={{ marginBottom: '15px' }}>
                                <label style={{ display: 'block', marginBottom: '5px', fontWeight: '500' }}>
                                    Date début *
                                </label>
                                <Input
                                    value={formData.dateDeb}
                                    onChange={value => setFormData(prev => ({...prev, dateDeb: value}))}
                                    placeholder="09/09/2024"
                                />
                            </div>
                            </Col>
                            <Col xs={12}>
                            <div style={{ marginBottom: '15px' }}>
                                <label style={{ display: 'block', marginBottom: '5px', fontWeight: '500' }}>
                                    Date fin *
                                </label>
                                <Input
                                    value={formData.dateFin}
                                    onChange={value => setFormData(prev => ({...prev, dateFin: value}))}
                                    placeholder="29/11/2024"
                                />
                            </div>
                            </Col>
                        </Row>

                        <Row gutter={16}>
                            <Col xs={12}>
                            <div style={{ marginBottom: '15px' }}>
                                <label style={{ display: 'block', marginBottom: '5px', fontWeight: '500' }}>
                                    Numéro Leçon *
                                </label>
                                <InputNumber
                                    value={formData.numLecon}
                                    onChange={value => setFormData(prev => ({...prev, numLecon: value}))}
                                    min={1}
                                    style={{ width: '100%' }}
                                />
                            </div>
                            </Col>
                            <Col xs={12}>
                            <div style={{ marginBottom: '15px' }}>
                                <label style={{ display: 'block', marginBottom: '5px', fontWeight: '500' }}>
                                    Ordre *
                                </label>
                                <InputNumber
                                    value={formData.ordre}
                                    onChange={value => setFormData(prev => ({...prev, ordre: value}))}
                                    min={1}
                                    style={{ width: '100%' }}
                                />
                            </div>
                            </Col>
                        </Row>

                        <div style={{ marginBottom: '15px' }}>
                            <label style={{ display: 'block', marginBottom: '5px', fontWeight: '500' }}>
                                Titre *
                            </label>
                            <Input
                                as="textarea"
                                rows={3}
                                value={formData.titre}
                                onChange={value => setFormData(prev => ({...prev, titre: value}))}
                                placeholder="Les salutations (Greetings)"
                            />
                        </div>

                        <Row gutter={16}>
                            <Col xs={12}>
                            <div style={{ marginBottom: '15px' }}>
                                <label style={{ display: 'block', marginBottom: '5px', fontWeight: '500' }}>
                                    Nombre d'heures *
                                </label>
                                <InputNumber
                                    value={formData.heure}
                                    onChange={value => setFormData(prev => ({...prev, heure: value}))}
                                    min={1}
                                    style={{ width: '100%' }}
                                />
                            </div>
                            </Col>
                            <Col xs={12}>
                            <div style={{ marginBottom: '15px' }}>
                                <label style={{ display: 'block', marginBottom: '5px', fontWeight: '500' }}>
                                    Nombre de séances *
                                </label>
                                <InputNumber
                                    value={formData.nbreSeance}
                                    onChange={value => setFormData(prev => ({...prev, nbreSeance: value}))}
                                    min={1}
                                    style={{ width: '100%' }}
                                />
                            </div>
                            </Col>
                        </Row>
                    </div>
                </Modal.Body>
                <Modal.Footer>
                    <Button onClick={() => setShowFormModal(false)} appearance="subtle">
                        Annuler
                    </Button>
                    <Button onClick={handleSave} appearance="primary">
                        {formMode === 'add' ? 'Ajouter' : 'Modifier'}
                    </Button>
                </Modal.Footer>
            </Modal>
        );
    };

    // ===========================
    // RENDU PRINCIPAL
    // ===========================
    return (
        <div style={{
            background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
            minHeight: '100vh',
            padding: '20px'
        }}>
            <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
                {/* En-tête */}
                <div style={{
                    background: 'white',
                    borderRadius: '15px',
                    padding: '25px',
                    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.08)',
                    marginBottom: '20px'
                }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div>
                            <h3 style={{ margin: 0, color: '#334155', fontWeight: '600' }}>
                                Référentiel des Progressions Pédagogiques
                            </h3>
                        </div>
                        <Button
                            appearance="primary"
                            size="lg"
                            startIcon={<FiUpload />}
                            onClick={() => setShowLoadModal(true)}
                            style={{
                                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                                border: 'none'
                            }}
                        >
                            Charger progression
                        </Button>
                    </div>
                </div>

                {/* Sélection année */}
                <div style={{
                    background: 'white',
                    borderRadius: '15px',
                    padding: '25px',
                    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.08)',
                    marginBottom: '20px'
                }}>
                    <Row gutter={20} style={{ alignItems: 'center' }}>
                        <Col xs={6}>
                            <div style={{
                                background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                                color: 'white',
                                padding: '15px 25px',
                                borderRadius: '8px',
                                textAlign: 'center',
                                fontWeight: '600'
                            }}>
                                Année scolaire
                            </div>
                        </Col>
                        <Col xs={18}>
                            <SelectPicker
                                data={anneesData}
                                value={selectedAnnee}
                                onChange={(value) => {
                                    setSelectedAnnee(value);
                                    if (value) {
                                        loadProgressionsByAnnee(value);
                                    }
                                }}
                                placeholder="Année 2024 - 2025 (Enseignement Secondaire Générale)"
                                style={{ width: '100%' }}
                                size="lg"
                                cleanable={false}
                            />
                        </Col>
                    </Row>
                </div>

                {/* Tableau des progressions */}
                {selectedAnnee && (
                    <div style={{
                        background: 'white',
                        borderRadius: '15px',
                        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.08)',
                        overflow: 'hidden'
                    }}>
                        <Table
                            height={500}
                            data={progressions}
                            loading={loading}
                        >
                            <Column width={150}>
                                <HeaderCell>Branche</HeaderCell>
                                <Cell dataKey="branche.libelle" />
                            </Column>

                            <Column flexGrow={1}>
                                <HeaderCell>Matière</HeaderCell>
                                <Cell dataKey="matiere.libelle" />
                            </Column>

                            <Column width={120} fixed="right">
                                <HeaderCell>Action</HeaderCell>
                                <Cell>
                                    {rowData => (
                                        <div style={{ display: 'flex', gap: 5 }}>
                                            <IconButton
                                                icon={<FiEdit />}
                                                size="sm"
                                                onClick={() => handleViewDetails(rowData)}
                                                style={{ color: '#3498db' }}
                                            />
                                            <IconButton
                                                icon={<FiTrash2 />}
                                                size="sm"
                                                color="red"
                                                appearance="subtle"
                                            />
                                        </div>
                                    )}
                                </Cell>
                            </Column>
                        </Table>
                    </div>
                )}
            </div>

            {/* Modals */}
            <LoadProgressionModal />
            <DetailsModal />
            <FormModal />
        </div>
    );
};

export default ProgressionPedagogique;