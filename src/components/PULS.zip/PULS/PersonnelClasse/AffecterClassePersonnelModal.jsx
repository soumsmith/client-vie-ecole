import React, { useState, useEffect, useCallback } from 'react';
import { Modal, Form, SelectPicker, Button, Message, Loader, Table, Panel, Divider } from 'rsuite';
import axios from 'axios';
import { useAllApiUrls } from '../utils/apiConfig';

const { Column, HeaderCell, Cell } = Table;

/**
 * Hook pour récupérer la liste des classes
 */
const useClassesData = (ecoleId = 38) => {
    const [classes, setClasses] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const apiUrls = useAllApiUrls();

    const fetchClasses = useCallback(async () => {
        setLoading(true);
        setError(null);
        try {
            const response = await axios.get(apiUrls.classes.listByEcoleSorted());
            const formattedClasses = (response.data || []).map(classe => ({
                label: `${classe.libelle} - ${classe.branche?.serie?.libelle || 'N/A'}`,
                value: classe.id,
                raw_data: classe
            }));
            setClasses(formattedClasses);
        } catch (err) {
            setError(err.message || 'Erreur lors du chargement des classes');
        } finally {
            setLoading(false);
        }
    }, [ecoleId, apiUrls.classes]);

    useEffect(() => {
        fetchClasses();
    }, [fetchClasses]);

    return { classes, loading, error, refetch: fetchClasses };
};

/**
 * Hook pour récupérer les données d'affectation d'une classe
 */
const useClasseAffectationData = () => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const apiUrls = useAllApiUrls();

    const fetchAffectationData = useCallback(async (classeId, anneeId = 226, ecoleId = 38) => {
        if (!classeId) {
            setData(null);
            return;
        }

        setLoading(true);
        setError(null);
        try {
            const response = await axios.get(
                apiUrls.affectations.getPpAndEducDtoByClasse(classeId)
            );
            setData(response.data);
        } catch (err) {
            setError(err.message || 'Erreur lors du chargement des données d\'affectation');
            setData(null);
        } finally {
            setLoading(false);
        }
    }, [apiUrls.affectations]);

    return { data, loading, error, fetchAffectationData };
};

/**
 * Hook pour récupérer le personnel disponible par classe
 */
const usePersonnelByClasse = () => {
    const [personnel, setPersonnel] = useState([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const apiUrls = useAllApiUrls();

    const fetchPersonnel = useCallback(async (classeId, anneeId = 226, ecoleId = 38) => {
        if (!classeId) {
            setPersonnel([]);
            return;
        }

        setLoading(true);
        setError(null);
        try {
            const response = await axios.get(
                apiUrls.affectations.getPersonnelByClasse(classeId)
            );
            setPersonnel(response.data || []);
        } catch (err) {
            setError(err.message || 'Erreur lors du chargement du personnel');
            setPersonnel([]);
        } finally {
            setLoading(false);
        }
    }, [apiUrls.affectations]);

    return { personnel, loading, error, fetchPersonnel };
};

/**
 * Modal d'affectation d'une classe à un personnel
 */
const AffecterClassePersonnelModal = ({ visible, onClose, onSuccess }) => {
    const [selectedClasse, setSelectedClasse] = useState(null);
    const [selectedProfesseur, setSelectedProfesseur] = useState(null);
    const [selectedEducateur, setSelectedEducateur] = useState(null);
    const [loading, setLoading] = useState(false);
    const [submitError, setSubmitError] = useState(null);
    const apiUrls = useAllApiUrls();

    // Hooks pour récupérer les données
    const { classes, loading: classesLoading } = useClassesData();
    const { data: affectationData, loading: affectationLoading, fetchAffectationData } = useClasseAffectationData();
    const { personnel, loading: personnelLoading, fetchPersonnel } = usePersonnelByClasse();

    // Filtrer le personnel par fonction
    const professeurs = personnel.filter(p => 
        p.personnel?.fonction?.libelle === 'PROFESSEUR' && p.typeFonction === 'PPRINC'
    );
    const educateurs = personnel.filter(p => 
        p.personnel?.fonction?.libelle === 'EDUCATEUR'
    );

    // Formatter les données pour les SelectPicker
    const professeursData = professeurs.map(prof => ({
        label: `${prof.personnel?.nom || ''} ${prof.personnel?.prenom || ''}`.trim(),
        value: prof.personnel?.id,
        raw_data: prof
    }));

    const educateursData = educateurs.map(educ => ({
        label: `${educ.personnel?.nom || ''} ${educ.personnel?.prenom || ''}`.trim(),
        value: educ.personnel?.id,
        raw_data: educ
    }));

    /**
     * Gestion du changement de classe
     */
    const handleClasseChange = useCallback((classeId) => {
        setSelectedClasse(classeId);
        setSelectedProfesseur(null);
        setSelectedEducateur(null);
        
        if (classeId) {
            fetchAffectationData(classeId);
            fetchPersonnel(classeId);
        }
    }, [fetchAffectationData, fetchPersonnel]);

    /**
     * Sélection automatique des professeurs et éducateurs s'il n'y en a qu'un seul
     */
    useEffect(() => {
        if (selectedClasse && !personnelLoading) {
            // Sélection automatique du professeur principal s'il n'y en a qu'un seul
            if (professeursData.length === 1 && !selectedProfesseur) {
                setSelectedProfesseur(professeursData[0].value);
            }
            
            // Sélection automatique de l'éducateur s'il n'y en a qu'un seul
            if (educateursData.length === 1 && !selectedEducateur) {
                setSelectedEducateur(educateursData[0].value);
            }
        }
    }, [selectedClasse, professeursData, educateursData, personnelLoading, selectedProfesseur, selectedEducateur]);

    /**
     * Soumission du formulaire
     */
    const handleSubmit = async () => {
        if (!selectedClasse) {
            Message.error('Veuillez sélectionner une classe');
            return;
        }

        if (!selectedProfesseur || !selectedEducateur) {
            Message.error('Veuillez sélectionner un professeur principal et un éducateur');
            return;
        }

        try {
            setLoading(true);
            setSubmitError(null);

            // Préparer les données d'affectation
            const affectationData = {
                classeId: selectedClasse,
                professeurId: selectedProfesseur,
                educateurId: selectedEducateur,
                anneeId: 226,
                ecoleId: 38
            };

            // Appel API pour enregistrer l'affectation
            const response = await axios.post(
                apiUrls.affectations.affecterClassePersonnel(),
                affectationData
            );
            
            // Succès
            handleReset();
            onSuccess(response.data);
            onClose();
            
            Message.success('Affectation créée avec succès');
            
        } catch (error) {
            const errorMessage = error.response?.data?.message || 
                               error.message || 
                               'Erreur lors de la création de l\'affectation';
            setSubmitError(errorMessage);
            Message.error(errorMessage);
        } finally {
            setLoading(false);
        }
    };

    /**
     * Annulation - fermer le modal
     */
    const handleCancel = () => {
        handleReset();
        onClose();
    };

    /**
     * Réinitialisation du formulaire
     */
    const handleReset = () => {
        setSelectedClasse(null);
        setSelectedProfesseur(null);
        setSelectedEducateur(null);
        setSubmitError(null);
    };

    /**
     * Réinitialisation quand le modal s'ouvre
     */
    useEffect(() => {
        if (visible) {
            handleReset();
        }
    }, [visible]);

    // Préparer les données du tableau des affectations créées
    const tableData = affectationData ? [{
        classe: affectationData.classe?.libelle || 'N/A',
        professeurPrincipal: affectationData.prof ? 
            `${affectationData.prof.nom || ''} ${affectationData.prof.prenom || ''}`.trim() : 'Non assigné',
        educateur: affectationData.educateur ? 
            `${affectationData.educateur.nom || ''} ${affectationData.educateur.prenom || ''}`.trim() : 'Non assigné'
    }] : [];

    const isDataLoading = classesLoading || affectationLoading || personnelLoading;

    return (
        <Modal open={visible} onClose={handleCancel} size="lg">
            <Modal.Header>
                <Modal.Title>Affecter une classe à un personnel</Modal.Title>
            </Modal.Header>
            
            <Modal.Body>
                {/* Affichage des erreurs */}
                {submitError && (
                    <div style={{ 
                        marginBottom: 16, 
                        padding: 12, 
                        backgroundColor: '#fff2f0', 
                        border: '1px solid #ffccc7',
                        borderRadius: 6,
                        color: '#a8071a'
                    }}>
                        <strong>Erreur : </strong>{submitError}
                    </div>
                )}

                {/* Formulaire de sélection */}
                <Form disabled={loading || isDataLoading} fluid>
                    {/* Sélection de la classe */}
                    <Form.Group controlId="classe">
                        <Form.ControlLabel>Classe</Form.ControlLabel>
                        <SelectPicker
                            data={classes}
                            value={selectedClasse}
                            onChange={handleClasseChange}
                            placeholder="Sélectionner une classe"
                            searchable
                            cleanable={false}
                            loading={classesLoading}
                            style={{ width: '100%' }}
                            size="lg"
                        />
                    </Form.Group>

                    {/* Sélection du professeur principal */}
                    <Form.Group controlId="professeur">
                        <Form.ControlLabel>Professeur Principal</Form.ControlLabel>
                        <SelectPicker
                            data={professeursData}
                            value={selectedProfesseur}
                            onChange={setSelectedProfesseur}
                            placeholder="Sélectionner un professeur principal"
                            searchable
                            cleanable={false}
                            loading={personnelLoading}
                            disabled={!selectedClasse || personnelLoading}
                            style={{ width: '100%' }}
                            size="lg"
                        />
                        {selectedClasse && professeursData.length === 0 && !personnelLoading && (
                            <div style={{ fontSize: '12px', color: '#999', marginTop: 4 }}>
                                Aucun professeur principal disponible pour cette classe
                            </div>
                        )}
                    </Form.Group>

                    {/* Sélection de l'éducateur */}
                    <Form.Group controlId="educateur">
                        <Form.ControlLabel>Educateur</Form.ControlLabel>
                        <SelectPicker
                            data={educateursData}
                            value={selectedEducateur}
                            onChange={setSelectedEducateur}
                            placeholder="Sélectionner un éducateur"
                            searchable
                            cleanable={false}
                            loading={personnelLoading}
                            disabled={!selectedClasse || personnelLoading}
                            style={{ width: '100%' }}
                            size="lg"
                        />
                        {selectedClasse && educateursData.length === 0 && !personnelLoading && (
                            <div style={{ fontSize: '12px', color: '#999', marginTop: 4 }}>
                                Aucun éducateur disponible pour cette classe
                            </div>
                        )}
                    </Form.Group>
                </Form>

                {/* Divider */}
                <Divider style={{ margin: '20px 0' }} />

                {/* Section des affectations créées */}
                <div style={{ marginTop: 20 }}>
                    <h6 style={{ 
                        margin: '0 0 15px 0', 
                        color: '#666', 
                        fontSize: '14px',
                        fontWeight: '600'
                    }}>
                        Affectations créés
                    </h6>

                    {/* Indicateur de chargement pour les données d'affectation */}
                    {affectationLoading && (
                        <div style={{ textAlign: 'center', padding: 20 }}>
                            <Loader size="sm" />
                            <div style={{ marginTop: 8, color: '#666', fontSize: '12px' }}>
                                Chargement des affectations...
                            </div>
                        </div>
                    )}

                    {/* Tableau des affectations */}
                    {!affectationLoading && (
                        <Table
                            data={tableData}
                            autoHeight
                            style={{ 
                                border: '1px solid #e5e5ea',
                                borderRadius: '8px',
                                overflow: 'hidden'
                            }}
                        >
                            <Column width={120} align="center" fixed>
                                <HeaderCell style={{ backgroundColor: '#f7f9fc', fontWeight: '600' }}>
                                    CLASSE
                                </HeaderCell>
                                <Cell dataKey="classe" style={{ fontSize: '13px' }} />
                            </Column>

                            <Column width={180} align="center">
                                <HeaderCell style={{ backgroundColor: '#f7f9fc', fontWeight: '600' }}>
                                    PROFESSEUR PRINC.
                                </HeaderCell>
                                <Cell dataKey="professeurPrincipal" style={{ fontSize: '13px' }} />
                            </Column>

                            <Column width={160} align="center">
                                <HeaderCell style={{ backgroundColor: '#f7f9fc', fontWeight: '600' }}>
                                    EDUCATEUR
                                </HeaderCell>
                                <Cell dataKey="educateur" style={{ fontSize: '13px' }} />
                            </Column>
                        </Table>
                    )}

                    {/* Message si aucune classe sélectionnée */}
                    {!selectedClasse && !affectationLoading && (
                        <div style={{
                            textAlign: 'center',
                            padding: '30px 20px',
                            backgroundColor: '#f8f9fa',
                            border: '1px dashed #dee2e6',
                            borderRadius: '8px',
                            color: '#6c757d',
                            fontSize: '14px'
                        }}>
                            Sélectionnez une classe pour voir les affectations existantes
                        </div>
                    )}

                    {/* Message si aucune affectation trouvée */}
                    {selectedClasse && !affectationLoading && tableData.length === 0 && (
                        <div style={{
                            textAlign: 'center',
                            padding: '30px 20px',
                            backgroundColor: '#fff3cd',
                            border: '1px solid #ffeaa7',
                            borderRadius: '8px',
                            color: '#856404',
                            fontSize: '14px'
                        }}>
                            Aucune affectation trouvée pour cette classe
                        </div>
                    )}
                </div>

                {/* Indicateur de chargement global */}
                {isDataLoading && (
                    <div style={{ 
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        backgroundColor: 'rgba(255, 255, 255, 0.8)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        zIndex: 10
                    }}>
                        <div style={{ textAlign: 'center' }}>
                            <Loader size="lg" />
                            <div style={{ marginTop: 8, color: '#666' }}>
                                Chargement des données...
                            </div>
                        </div>
                    </div>
                )}
            </Modal.Body>
            
            <Modal.Footer>
                <Button 
                    onClick={handleSubmit} 
                    appearance="primary" 
                    loading={loading}
                    disabled={isDataLoading || !selectedClasse || !selectedProfesseur || !selectedEducateur}
                    color="green"
                    size="lg"
                    startIcon={<span>💾</span>}
                >
                    Enregistrer
                </Button>
                <Button 
                    onClick={handleCancel} 
                    appearance="subtle"
                    disabled={loading}
                    size="lg"
                >
                    Fermer
                </Button>
            </Modal.Footer>
        </Modal>
    );
};

export default AffecterClassePersonnelModal;