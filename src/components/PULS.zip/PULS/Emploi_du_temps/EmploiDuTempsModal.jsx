import React, { useState, useEffect, useCallback } from "react";
import {
  Modal,
  Button,
  Form,
  SelectPicker,
  Input,
  Panel,
  Grid,
  Row,
  Col,
  Badge,
  Text,
  Avatar,
  Message,
  Loader
} from "rsuite";
import {
  FiClock,
  FiBook,
  FiCalendar,
  FiCheck,
  FiX,
  FiAlertTriangle,
  FiSave,
  FiPlus,
} from "react-icons/fi";
import Swal from "sweetalert2";
import {
  useClassesData,
  useJoursData,
  useTypesActiviteData,
  useMatieresByClasse,
  checkCreneauDisponibilite,
  getSallesDisponibles,
  getActivitesByClasseJour,
  saveActivite,
} from "./EmploiDuTempsServiceManager";
import { usePulsParams } from "../../hooks/useDynamicParams";

const EmploiDuTempsModal = ({ modalState, onClose, onSave }) => {
  const { isOpen, type, selectedQuestion: activite } = modalState;
  const { ecoleId: dynamicEcoleId, academicYearId: dynamicAcademicYearId } = usePulsParams();


  const [formData, setFormData] = useState({
    classeId: null,
    jourId: null,
    heureDeb: "",
    heureFin: "",
    matiereId: null,
    salleId: null,
    typeActiviteId: null,
  });

  // ===========================
  // CHARGEMENT DES ACTIVITÉS EXISTANTES
  // ===========================
  const chargerActivitesExistantes = useCallback(async () => {
    if (formData.classeId && formData.jourId && type === "edit") {
      setLoadingActivites(true);
      try {
        const activites = await getActivitesByClasseJour(
          dynamicAcademicYearId,
          formData.classeId,
          formData.jourId
        );
        setActivitesExistantes(activites);
      } catch (error) {
        console.error("Erreur lors du chargement des activités:", error);
        setActivitesExistantes([]);
      } finally {
        setLoadingActivites(false);
      }
    }
  }, [formData.classeId, formData.jourId, type, dynamicAcademicYearId]);

  // ===========================
  // STATE SIMPLIFIÉ
  // ===========================
  

  const [verfication, setVerification] = useState({
    creneauDisponible: null,
    sallesDisponibles: [],
    loading: false,
    error: null
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activitesExistantes, setActivitesExistantes] = useState([]);
  const [loadingActivites, setLoadingActivites] = useState(false);

  // ===========================
  // HOOKS POUR LES DONNÉES
  // ===========================
  const { classes } = useClassesData(dynamicEcoleId);
  const { jours } = useJoursData();
  const { typesActivite } = useTypesActiviteData(dynamicEcoleId);
  const { matieres } = useMatieresByClasse(formData.classeId);

  // ===========================
  // PRÉPARATION DES OPTIONS
  // ===========================
  const classesOptions = classes.map(classe => ({
    label: classe.libelle,
    value: classe.id
  }));

  const joursOptions = jours.map(jour => ({
    label: jour.libelle,
    value: jour.id
  }));

  const matieresOptions = matieres.map(matiere => ({
    label: matiere.matiere.libelle,
    value: matiere.matiere.id
  }));

  const sallesOptions = verfication.sallesDisponibles.map(salle => ({
    label: salle.libelle,
    value: salle.id
  }));

  const typesActiviteOptions = typesActivite.map(type => ({
    label: type.libelle,
    value: type.id
  }));

  // ===========================
  // FONCTIONS DE VALIDATION
  // ===========================
  const validateTimeRange = useCallback(() => {
    const { heureDeb, heureFin } = formData;

    if (!heureDeb || !heureFin) {
      return { valid: false, message: "Les heures de début et fin sont obligatoires" };
    }

    const [debutH, debutM] = heureDeb.split(':').map(Number);
    const [finH, finM] = heureFin.split(':').map(Number);
    
    const debutMinutes = debutH * 60 + debutM;
    const finMinutes = finH * 60 + finM;

    if (finMinutes <= debutMinutes) {
      return { valid: false, message: "L'heure de fin doit être supérieure à l'heure de début" };
    }

    if (finMinutes - debutMinutes < 15) {
      return { valid: false, message: "Il doit y avoir au moins 15 minutes entre le début et la fin" };
    }

    return { valid: true, message: null };
  }, [formData.heureDeb, formData.heureFin]);

  const isFormValid = useCallback(() => {
    const requiredFields = ['classeId', 'jourId', 'heureDeb', 'heureFin', 'matiereId', 'salleId', 'typeActiviteId'];
    const hasAllFields = requiredFields.every(field => formData[field]);
    const timeValidation = validateTimeRange();
    
    return hasAllFields && timeValidation.valid && verfication.creneauDisponible;
  }, [formData, validateTimeRange, verfication.creneauDisponible]);

  // ===========================
  // VÉRIFICATION DE DISPONIBILITÉ
  // ===========================
  const verifierDisponibilite = useCallback(async () => {
    const { classeId, jourId, heureDeb, heureFin } = formData;

    // Reset de l'état de vérification
    setVerification(prev => ({
      ...prev,
      creneauDisponible: null,
      sallesDisponibles: [],
      error: null
    }));

    // Vérification des prérequis
    if (!classeId || !jourId || !heureDeb || !heureFin) {
      return;
    }

    // Validation des heures
    const timeValidation = validateTimeRange();
    if (!timeValidation.valid) {
      setVerification(prev => ({
        ...prev,
        creneauDisponible: false,
        error: timeValidation.message
      }));
      return;
    }

    setVerification(prev => ({ ...prev, loading: true }));

    try {
      // Vérifier la disponibilité du créneau
      const disponible = await checkCreneauDisponibilite(
        dynamicAcademicYearId,
        classeId,
        jourId,
        heureDeb,
        heureFin
      );

      if (disponible) {
        // Si disponible, récupérer les salles
        const salles = await getSallesDisponibles(
          dynamicAcademicYearId,
          classeId,
          jourId,
          heureDeb,
          heureFin
        );

        setVerification({
          creneauDisponible: true,
          sallesDisponibles: salles,
          loading: false,
          error: null
        });
      } else {
        setVerification({
          creneauDisponible: false,
          sallesDisponibles: [],
          loading: false,
          error: "Ce créneau n'est pas disponible"
        });
      }
    } catch (error) {
      console.error('Erreur lors de la vérification:', error);
      setVerification({
        creneauDisponible: false,
        sallesDisponibles: [],
        loading: false,
        error: "Erreur lors de la vérification de disponibilité"
      });
    }
  }, [formData, validateTimeRange, dynamicAcademicYearId]);

  // ===========================
  // GESTION DES CHANGEMENTS
  // ===========================
  const handleFieldChange = useCallback((field, value) => {
    setFormData(prev => {
      const newData = { ...prev, [field]: value };
      
      // Reset des champs dépendants
      if (field === 'classeId') {
        newData.matiereId = null;
        newData.salleId = null;
      }
      
      // Reset de la salle si les paramètres de vérification changent
      if (['classeId', 'jourId', 'heureDeb', 'heureFin'].includes(field)) {
        newData.salleId = null;
      }

      return newData;
    });
  }, []);

  // ===========================
  // EFFECTS
  // ===========================
  
  // Initialisation du formulaire
  useEffect(() => {
    if (type === "edit" && activite && isOpen) {
      setFormData({
        classeId: activite.classeId,
        jourId: activite.jourId,
        heureDeb: activite.heureDeb || "",
        heureFin: activite.heureFin || "",
        matiereId: activite.matiereId,
        salleId: activite.salleId,
        typeActiviteId: activite.typeActiviteId,
      });
    } else if (type === "create") {
      setFormData({
        classeId: null,
        jourId: null,
        heureDeb: "",
        heureFin: "",
        matiereId: null,
        salleId: null,
        typeActiviteId: null,
      });
      setVerification({
        creneauDisponible: null,
        sallesDisponibles: [],
        loading: false,
        error: null
      });
    }
  }, [type, activite, isOpen]);

  // Vérification automatique uniquement quand l'heure de fin change
  useEffect(() => {
    const { classeId, jourId, heureDeb, heureFin } = formData;
    
    // Vérifier seulement si tous les champs requis sont remplis et que l'heure de fin a changé
    if (classeId && jourId && heureDeb && heureFin) {
      const timer = setTimeout(() => {
        verifierDisponibilite();
      }, 300); // Debounce pour éviter trop d'appels

      return () => clearTimeout(timer);
    } else {
      // Reset de la vérification si les champs requis ne sont pas tous remplis
      setVerification({
        creneauDisponible: null,
        sallesDisponibles: [],
        loading: false,
        error: null
      });
    }
  }, [formData.heureFin]); // Déclenchement uniquement sur changement de l'heure de fin

  // Chargement des activités existantes (mode modification)
  useEffect(() => {
    if (type === "edit") {
      chargerActivitesExistantes();
    }
  }, [chargerActivitesExistantes, type]);

  // ===========================
  // SAUVEGARDE
  // ===========================
  const handleSave = async () => {
    if (!isFormValid()) {
      Swal.fire({
        icon: "warning",
        title: "Formulaire incomplet",
        text: "Veuillez remplir tous les champs obligatoires et vérifier la disponibilité du créneau.",
        confirmButtonColor: "#10b981",
      });
      return;
    }

    const result = await Swal.fire({
      title: type === "create" ? "Créer l'activité" : "Modifier l'activité",
      text: `Confirmer ${type === "create" ? "la création de" : "la modification de"} cette activité ?`,
      icon: "question",
      showCancelButton: true,
      confirmButtonColor: "#10b981",
      cancelButtonColor: "#6b7280",
      confirmButtonText: "Oui, confirmer",
      cancelButtonText: "Annuler",
    });

    if (!result.isConfirmed) return;

    setIsSubmitting(true);

    try {
      // Récupérer les objets complets pour l'API
      const classe = classes.find(c => c.id === formData.classeId);
      const jour = jours.find(j => j.id === formData.jourId);
      const matiere = matieres.find(m => m.matiere.id === formData.matiereId)?.matiere;
      const salle = verfication.sallesDisponibles.find(s => s.id === formData.salleId);
      const typeActivite = typesActivite.find(t => t.id === formData.typeActiviteId);

      const activiteData = {
        jour: { id: jour.id, libelle: null },
        heureDeb: formData.heureDeb,
        heureFin: formData.heureFin,
        matiere: { id: matiere.id, libelle: null },
        classe: { id: classe.id, libelle: null },
        salle: { id: salle.id, libelle: null },
        typeActivite: { id: typeActivite.id, libelle: null },
        user: "361",
        annee: dynamicAcademicYearId.toString(),
        ecole: { id: dynamicEcoleId.toString() },
        profPrincipal: null,
      };

      const response = await saveActivite(activiteData);

      await Swal.fire({
        icon: "success",
        title: `Activité ${type === "create" ? "créée" : "modifiée"} !`,
        text: `L'activité a été ${type === "create" ? "créée" : "modifiée"} avec succès.`,
        confirmButtonColor: "#10b981",
        timer: 3000,
      });

      if (onSave) onSave(response);
      onClose();
    } catch (error) {
      console.error("Erreur lors de la sauvegarde:", error);
      
      let errorMessage = "Une erreur inattendue est survenue.";
      if (error.response?.status === 400) {
        errorMessage = "Données invalides. Vérifiez les informations saisies.";
      } else if (error.response?.status === 409) {
        errorMessage = "Ce créneau est déjà occupé.";
      }

      await Swal.fire({
        icon: "error",
        title: "Erreur de sauvegarde",
        text: errorMessage,
        confirmButtonColor: "#ef4444",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // ===========================
  // FONCTIONS UTILITAIRES
  // ===========================
  const formatTime = (time) => {
    if (!time) return "";
    return time.substring(0, 5);
  };

  // ===========================
  // COMPOSANT DE STATUT DE VÉRIFICATION
  // ===========================
  const VerificationStatus = () => {
    const timeValidation = validateTimeRange();
    
    if (!formData.heureDeb || !formData.heureFin) return null;

    if (!timeValidation.valid) {
      return (
        <Message type="warning" showIcon style={{ marginBottom: 16 }}>
          <FiAlertTriangle style={{ marginRight: 8 }} />
          {timeValidation.message}
        </Message>
      );
    }

    if (verfication.loading) {
      return (
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          padding: 12,
          background: '#f0f9ff',
          border: '1px solid #bae6fd',
          borderRadius: 8,
          marginBottom: 16
        }}>
          <Loader size="xs" />
          <Text style={{ color: '#0369a1' }}>Vérification de la disponibilité...</Text>
        </div>
      );
    }

    if (verfication.error) {
      return (
        <Message type="error" showIcon style={{ marginBottom: 16, marginTop :16 }}>
          <FiAlertTriangle style={{ marginRight: 8 }} />
          {verfication.error}
        </Message>
      );
    }

    if (verfication.creneauDisponible === true) {
      return (
        <Message type="success" showIcon style={{ marginBottom: 16, marginTop :16  }}>
          <FiCheck style={{ marginRight: 8 }} />
          Créneau disponible • {verfication.sallesDisponibles.length} salle(s) disponible(s)
        </Message>
      );
    }

    if (verfication.creneauDisponible === false) {
      return (
        <Message type="error" showIcon style={{ marginBottom: 16, marginTop : 16 }}>
          <FiX style={{ marginRight: 8 }} />
          Créneau indisponible
        </Message>
      );
    }

    return null;
  };

  return (
    <Modal
      open={isOpen}
      onClose={onClose}
      size="lg"
      backdrop="static"
      style={{ borderRadius: "16px", overflow: "hidden" }}
    >
      {/* Header */}
      <Modal.Header
        style={{
          background: "#ffffff",
          borderBottom: "1px solid #f1f5f9",
          padding: "24px",
          borderRadius: "16px 16px 0 0",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
          <Avatar
            size="lg"
            style={{
              background: type === "create" ? "#10b981" : "#6366f1",
              color: "white",
              fontWeight: "600",
              fontSize: "18px",
            }}
          >
            {type === "create" ? <FiPlus /> : <FiClock />}
          </Avatar>
          <div style={{ flex: 1 }}>
            <Text size="lg" weight="semibold" style={{ color: "#0f172a", marginBottom: "4px" }}>
              {type === "create" ? "Créer une nouvelle activité" : "Modifier une activité"}
            </Text>
            <Badge
              style={{
                background: "#f1f5f9",
                color: "#475569",
                fontWeight: "500",
                border: "1px solid #e2e8f0",
              }}
            >
              EMPLOI DU TEMPS
            </Badge>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <FiCalendar size={20} style={{ color: "#6366f1" }} />
            <Text size="md" weight="semibold" style={{ color: "#1e293b" }}>
              Planification
            </Text>
          </div>
        </div>
      </Modal.Header>

      <Modal.Body
        style={{
          padding: "32px 24px",
          background: "#fafafa",
          maxHeight: "70vh",
          overflowY: "auto",
        }}
      >
        <Grid fluid>
          <Row gutter={24}>
            {/* Formulaire principal */}
            <Col xs={type === "edit" ? 14 : 24}>
              <Panel
                header={
                  <Text size="md" weight="semibold" style={{ color: "#1e293b" }}>
                    <FiBook style={{ marginRight: "8px" }} />
                    Détails de l'activité
                  </Text>
                }
                style={{
                  background: "white",
                  borderRadius: "12px",
                  border: "1px solid #f1f5f9",
                  boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.05)",
                  marginBottom: "24px",
                }}
                bodyStyle={{ padding: "20px" }}
              >
                <Form fluid>
                  <Grid fluid>
                    <Row gutter={16}>
                      <Col xs={12}>
                        <Form.Group>
                          <Form.ControlLabel style={{ fontWeight: "500", color: "#374151" }}>
                            Classe <span style={{ color: "#ef4444" }}>*</span>
                          </Form.ControlLabel>
                          <SelectPicker
                            data={classesOptions}
                            value={formData.classeId}
                            onChange={(value) => handleFieldChange('classeId', value)}
                            placeholder="Sélectionner la classe"
                            cleanable={false}
                            disabled={isSubmitting}
                            style={{ width: "100%" }}
                          />
                        </Form.Group>
                      </Col>
                      <Col xs={12}>
                        <Form.Group>
                          <Form.ControlLabel style={{ fontWeight: "500", color: "#374151" }}>
                            Jour <span style={{ color: "#ef4444" }}>*</span>
                          </Form.ControlLabel>
                          <SelectPicker
                            data={joursOptions}
                            value={formData.jourId}
                            onChange={(value) => handleFieldChange('jourId', value)}
                            placeholder="Sélectionner le jour"
                            cleanable={false}
                            disabled={isSubmitting}
                            style={{ width: "100%" }}
                          />
                        </Form.Group>
                      </Col>
                    </Row>

                    <Row gutter={16}>
                      <Col xs={12}>
                        <Form.Group>
                          <Form.ControlLabel style={{ fontWeight: "500", color: "#374151" }}>
                            Heure début <span style={{ color: "#ef4444" }}>*</span>
                          </Form.ControlLabel>
                          <Input
                            type="time"
                            value={formData.heureDeb}
                            onChange={(value) => handleFieldChange('heureDeb', value)}
                            disabled={isSubmitting}
                            style={{ width: "100%" }}
                          />
                        </Form.Group>
                      </Col>
                      <Col xs={12}>
                        <Form.Group>
                          <Form.ControlLabel style={{ fontWeight: "500", color: "#374151" }}>
                            Heure fin <span style={{ color: "#ef4444" }}>*</span>
                          </Form.ControlLabel>
                          <Input
                            type="time"
                            value={formData.heureFin}
                            onChange={(value) => handleFieldChange('heureFin', value)}
                            disabled={isSubmitting}
                            style={{ width: "100%" }}
                          />
                        </Form.Group>
                      </Col>
                    </Row>

                    {/* Statut de vérification */}
                    <VerificationStatus />

                    <Row gutter={16}>
                      <Col xs={12}>
                        <Form.Group>
                          <Form.ControlLabel style={{ fontWeight: "500", color: "#374151" }}>
                            Matière <span style={{ color: "#ef4444" }}>*</span>
                          </Form.ControlLabel>
                          <SelectPicker
                            data={matieresOptions}
                            value={formData.matiereId}
                            onChange={(value) => handleFieldChange('matiereId', value)}
                            placeholder="Sélectionner la matière"
                            cleanable={false}
                            disabled={isSubmitting || !formData.classeId}
                            style={{ width: "100%" }}
                          />
                        </Form.Group>
                      </Col>
                      <Col xs={12}>
                        <Form.Group>
                          <Form.ControlLabel style={{ fontWeight: "500", color: "#374151" }}>
                            Type d'activité <span style={{ color: "#ef4444" }}>*</span>
                          </Form.ControlLabel>
                          <SelectPicker
                            data={typesActiviteOptions}
                            value={formData.typeActiviteId}
                            onChange={(value) => handleFieldChange('typeActiviteId', value)}
                            placeholder="Sélectionner le type d'activité"
                            cleanable={false}
                            disabled={isSubmitting}
                            style={{ width: "100%" }}
                          />
                        </Form.Group>
                      </Col>
                    </Row>

                    <Row>
                      <Col xs={24}>
                        <Form.Group>
                          <Form.ControlLabel style={{ fontWeight: "500", color: "#374151" }}>
                            Salle disponible <span style={{ color: "#ef4444" }}>*</span>
                          </Form.ControlLabel>
                          <SelectPicker
                            data={sallesOptions}
                            value={formData.salleId}
                            onChange={(value) => handleFieldChange('salleId', value)}
                            placeholder={
                              verfication.loading
                                ? "Vérification en cours..."
                                : verfication.creneauDisponible
                                ? "Sélectionner la salle"
                                : "Vérifiez d'abord la disponibilité du créneau"
                            }
                            cleanable={false}
                            disabled={isSubmitting || !verfication.creneauDisponible || verfication.loading}
                            style={{ width: "100%" }}
                          />
                        </Form.Group>
                      </Col>
                    </Row>
                  </Grid>
                </Form>
              </Panel>
            </Col>

            {/* Emploi du temps défini (mode modification) */}
            {type === "edit" && (
              <Col xs={10}>
                <Panel
                  header={
                    <Text size="md" weight="semibold" style={{ color: "#1e293b" }}>
                      <FiClock style={{ marginRight: "8px" }} />
                      Emploi du temps défini
                    </Text>
                  }
                  style={{
                    background: "white",
                    borderRadius: "12px",
                    border: "1px solid #f1f5f9",
                    boxShadow: "0 1px 3px 0 rgba(0, 0, 0, 0.05)",
                    height: "400px",
                  }}
                  bodyStyle={{
                    padding: "16px",
                    height: "100%",
                    overflowY: "auto",
                  }}
                >
                  {loadingActivites ? (
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      height: '100%',
                      gap: 10
                    }}>
                      <Loader size="sm" />
                      <Text style={{ color: '#64748b' }}>Chargement...</Text>
                    </div>
                  ) : activitesExistantes.length > 0 ? (
                    <div style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: "12px",
                    }}>
                      {activitesExistantes.map((act, index) => (
                        <div
                          key={index}
                          style={{
                            background: "#f8fafc",
                            border: "1px solid #e2e8f0",
                            borderRadius: "8px",
                            padding: "12px",
                          }}
                        >
                          <div style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            marginBottom: "8px",
                          }}>
                            <Text
                              weight="semibold"
                              style={{ fontSize: "13px", color: "#1e293b" }}
                            >
                              {formatTime(act.heureDeb)} - {formatTime(act.heureFin)}
                            </Text>
                            <Badge style={{
                              background: "#6366f1",
                              color: "white",
                              fontSize: "10px",
                            }}>
                              {act.matiere?.libelle}
                            </Badge>
                          </div>
                          <Text size="xs" style={{ color: "#64748b" }}>
                            {act.salle?.libelle} • {act.typeActivite?.libelle}
                          </Text>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      justifyContent: "center",
                      height: "100%",
                      color: "#64748b",
                    }}>
                      <FiClock size={32} style={{ marginBottom: "12px" }} />
                      <Text muted>
                        {formData.classeId && formData.jourId
                          ? "Aucune activité définie"
                          : "Sélectionnez une classe et un jour"}
                      </Text>
                    </div>
                  )}
                </Panel>
              </Col>
            )}
          </Row>
        </Grid>
      </Modal.Body>

      <Modal.Footer
        style={{
          padding: "20px 24px",
          borderTop: "1px solid #f1f5f9",
          background: "white",
          borderRadius: "0 0 16px 16px",
        }}
      >
        <div style={{ display: "flex", gap: "12px", justifyContent: "flex-end" }}>
          <Button
            appearance="subtle"
            onClick={onClose}
            disabled={isSubmitting}
            startIcon={<FiX />}
            style={{
              color: "#64748b",
              border: "1px solid #e2e8f0",
              borderRadius: "8px",
              padding: "8px 16px",
            }}
          >
            Fermer
          </Button>
          <Button
            appearance="primary"
            onClick={handleSave}
            loading={isSubmitting}
            disabled={!isFormValid() || isSubmitting}
            startIcon={<FiSave />}
            style={{
              background: isSubmitting
                ? "#94a3b8"
                : "linear-gradient(135deg, #10b981 0%, #059669 100%)",
              border: "none",
              borderRadius: "8px",
              padding: "8px 20px",
              fontWeight: "600",
            }}
          >
            {isSubmitting
              ? type === "create"
                ? "Création..."
                : "Modification..."
              : type === "create"
              ? "Enregistrer"
              : "Modifier"}
          </Button>
        </div>
      </Modal.Footer>
    </Modal>
  );
};

export default EmploiDuTempsModal;